
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.justblocksreblocked.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;

import net.mcreator.justblocksreblocked.block.BluxycaWorldPortalBlock;
import net.mcreator.justblocksreblocked.block.BluxycaOREBlock;
import net.mcreator.justblocksreblocked.block.BluxycaBlock;
import net.mcreator.justblocksreblocked.JustblocksReblockedMod;

public class JustblocksReblockedModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(JustblocksReblockedMod.MODID);
	public static final DeferredHolder<Block, Block> BLUXYCA = REGISTRY.register("bluxyca", BluxycaBlock::new);
	public static final DeferredHolder<Block, Block> BLUXYCA_ORE = REGISTRY.register("bluxyca_ore", BluxycaOREBlock::new);
	public static final DeferredHolder<Block, Block> BLUXYCA_WORLD_PORTAL = REGISTRY.register("bluxyca_world_portal", BluxycaWorldPortalBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
