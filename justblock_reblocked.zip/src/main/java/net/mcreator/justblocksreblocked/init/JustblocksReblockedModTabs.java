
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.justblocksreblocked.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.justblocksreblocked.JustblocksReblockedMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JustblocksReblockedModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JustblocksReblockedMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(JustblocksReblockedModItems.BLUXYCA_SWORD.get());
			tabData.accept(JustblocksReblockedModItems.BLUXYCA_ARMOR_HELMET.get());
			tabData.accept(JustblocksReblockedModItems.BLUXYCA_ARMOR_CHESTPLATE.get());
			tabData.accept(JustblocksReblockedModItems.BLUXYCA_ARMOR_LEGGINGS.get());
			tabData.accept(JustblocksReblockedModItems.BLUXYCA_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(JustblocksReblockedModItems.BLUXYCAFRAGMENT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(JustblocksReblockedModBlocks.BLUXYCA.get().asItem());
			tabData.accept(JustblocksReblockedModBlocks.BLUXYCA_ORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(JustblocksReblockedModItems.BLUXYCA_PICKAXE.get());
			tabData.accept(JustblocksReblockedModItems.BLUXYCA_AXE.get());
			tabData.accept(JustblocksReblockedModItems.BLUXYCA_WORLD.get());
			tabData.accept(JustblocksReblockedModItems.BLUXYCA_HOE.get());
			tabData.accept(JustblocksReblockedModItems.BLUXYCA_SPADE.get());
		}
	}
}
