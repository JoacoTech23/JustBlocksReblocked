
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.justblocksreblocked.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.justblocksreblocked.item.BluxycafragmentItem;
import net.mcreator.justblocksreblocked.item.BluxycaWorldItem;
import net.mcreator.justblocksreblocked.item.BluxycaSwordItem;
import net.mcreator.justblocksreblocked.item.BluxycaSpadeItem;
import net.mcreator.justblocksreblocked.item.BluxycaPickaxeItem;
import net.mcreator.justblocksreblocked.item.BluxycaHoeItem;
import net.mcreator.justblocksreblocked.item.BluxycaAxeItem;
import net.mcreator.justblocksreblocked.item.BluxycaArmorItem;
import net.mcreator.justblocksreblocked.JustblocksReblockedMod;

public class JustblocksReblockedModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JustblocksReblockedMod.MODID);
	public static final DeferredHolder<Item, Item> BLUXYCA = block(JustblocksReblockedModBlocks.BLUXYCA);
	public static final DeferredHolder<Item, Item> BLUXYCAFRAGMENT = REGISTRY.register("bluxycafragment", BluxycafragmentItem::new);
	public static final DeferredHolder<Item, Item> BLUXYCA_ORE = block(JustblocksReblockedModBlocks.BLUXYCA_ORE);
	public static final DeferredHolder<Item, Item> BLUXYCA_PICKAXE = REGISTRY.register("bluxyca_pickaxe", BluxycaPickaxeItem::new);
	public static final DeferredHolder<Item, Item> BLUXYCA_SWORD = REGISTRY.register("bluxyca_sword", BluxycaSwordItem::new);
	public static final DeferredHolder<Item, Item> BLUXYCA_AXE = REGISTRY.register("bluxyca_axe", BluxycaAxeItem::new);
	public static final DeferredHolder<Item, Item> BLUXYCA_WORLD = REGISTRY.register("bluxyca_world", BluxycaWorldItem::new);
	public static final DeferredHolder<Item, Item> BLUXYCA_ARMOR_HELMET = REGISTRY.register("bluxyca_armor_helmet", BluxycaArmorItem.Helmet::new);
	public static final DeferredHolder<Item, Item> BLUXYCA_ARMOR_CHESTPLATE = REGISTRY.register("bluxyca_armor_chestplate", BluxycaArmorItem.Chestplate::new);
	public static final DeferredHolder<Item, Item> BLUXYCA_ARMOR_LEGGINGS = REGISTRY.register("bluxyca_armor_leggings", BluxycaArmorItem.Leggings::new);
	public static final DeferredHolder<Item, Item> BLUXYCA_ARMOR_BOOTS = REGISTRY.register("bluxyca_armor_boots", BluxycaArmorItem.Boots::new);
	public static final DeferredHolder<Item, Item> BLUXYCA_HOE = REGISTRY.register("bluxyca_hoe", BluxycaHoeItem::new);
	public static final DeferredHolder<Item, Item> BLUXYCA_SPADE = REGISTRY.register("bluxyca_spade", BluxycaSpadeItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
